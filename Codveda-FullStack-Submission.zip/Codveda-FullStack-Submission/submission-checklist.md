# Codveda Submission Checklist

## Level 1
- [ ] Node/npm/VS Code/Git installed
- [ ] GitHub repository created
- [ ] Express REST API working
- [ ] GET/POST/PUT/DELETE tested in Postman/Thunder Client
- [ ] Vanilla JS frontend consumes the API

## Level 2
- [ ] React frontend working
- [ ] Functional components + state + API calls
- [ ] JWT login/signup
- [ ] bcrypt password hashing
- [ ] Protected routes / role-based authorization
- [ ] MongoDB + Mongoose CRUD
- [ ] Validation + indexes

## Level 3
- [ ] Full-stack integration working
- [ ] Frontend and backend build/run successfully
- [ ] Socket.io real-time notifications working
- [ ] Deployment links added (when deployed)
- [ ] GitHub README completed
- [ ] Demo video recorded
- [ ] LinkedIn post prepared

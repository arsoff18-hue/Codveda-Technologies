const API = 'http://localhost:5000/api';
let token = localStorage.getItem('codveda_token');
let currentUser = JSON.parse(localStorage.getItem('codveda_user') || 'null');

const $ = (id) => document.getElementById(id);
function headers(){ return { 'Content-Type':'application/json', ...(token ? {Authorization:`Bearer ${token}`} : {})}; }
function setUser(user){ currentUser=user; localStorage.setItem('codveda_user',JSON.stringify(user)); $('userBadge').textContent=`${user.name} (${user.role})`; }
if(currentUser) setUser(currentUser);

async function api(path, options={}){
  const res=await fetch(API+path,{...options,headers:{...headers(),...(options.headers||{})}});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message||'Request failed');
  return data;
}

$('loginForm').addEventListener('submit',async(e)=>{
  e.preventDefault();
  try{
    const data=await api('/auth/login',{method:'POST',body:JSON.stringify({email:$('email').value,password:$('password').value})});
    token=data.token; localStorage.setItem('codveda_token',token); setUser(data.user); $('loginMessage').textContent='Login successful'; loadTasks();
  }catch(err){$('loginMessage').textContent=err.message}
});

$('taskForm').addEventListener('submit',async(e)=>{
  e.preventDefault();
  try{
    await api('/tasks',{method:'POST',body:JSON.stringify({title:$('title').value,description:$('description').value,priority:$('priority').value})});
    e.target.reset(); $('priority').value='medium'; loadTasks();
  }catch(err){alert(err.message)}
});
$('refresh').addEventListener('click',loadTasks);

async function loadTasks(){
  if(!token){$('tasks').innerHTML='<p class="muted">Login first.</p>';return;}
  try{const tasks=await api('/tasks'); $('tasks').innerHTML=tasks.map(t=>`<div class="task"><strong>${escapeHtml(t.title)}</strong><p>${escapeHtml(t.description||'')}</p><span class="muted">${t.status} • ${t.priority}</span></div>`).join('')||'<p class="muted">No tasks yet.</p>'}
  catch(err){$('tasks').innerHTML=`<p>${err.message}</p>`}
}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
loadTasks();

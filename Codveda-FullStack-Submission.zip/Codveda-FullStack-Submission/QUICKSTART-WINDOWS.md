# TODAY — Fastest Setup & Submission

Do these steps in order. Do not change the folder structure unless necessary.

## STEP 1 — Extract ZIP
Extract `Codveda-FullStack-Submission.zip` to Desktop.

Open the folder in VS Code.

## STEP 2 — MongoDB
Fastest option if MongoDB is not already installed: use MongoDB Atlas.

Create an Atlas project/cluster, create a database user, allow your current IP in Network Access, then use **Connect → Drivers** to copy the application connection string. Put that string into `backend/.env` as `MONGO_URI`.

Example:

```env
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@CLUSTER.mongodb.net/codveda_task_manager?retryWrites=true&w=majority
```

Also set:

```env
JWT_SECRET=codveda_demo_secret_change_before_sharing
CLIENT_URL=http://localhost:5173
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=Admin@12345
```

Never upload `.env` to GitHub.

## STEP 3 — Backend
Open a terminal in the project root:

```powershell
cd backend
copy .env.example .env
notepad .env
```

Save `.env` with your MongoDB URI and JWT secret.

Then:

```powershell
npm install
npm run create-admin
npm run dev
```

Keep this terminal running.

Test in browser:

`http://localhost:5000/api/health`

You should see JSON with `status: ok`.

## STEP 4 — React Frontend
Open a second terminal:

```powershell
cd frontend-react
npm install
npm run dev
```

Open the URL Vite prints in the terminal, normally a localhost URL.

Register a student account and login.

## STEP 5 — Demonstrate Level 2/3
Show these on screen:

1. Register
2. Login
3. Create task
4. Task appears in dashboard
5. Delete task
6. Explain JWT/bcrypt authentication
7. Explain MongoDB + Mongoose
8. Open another browser/window with a second logged-in user if you want to demonstrate real-time notifications

## STEP 6 — Level 1 Vanilla JavaScript
Open `frontend-vanilla/index.html` with VS Code Live Server.

Login and create/view tasks. This demonstrates the HTML/CSS/Vanilla JS frontend consuming the REST API through Fetch.

## STEP 7 — Postman
Import `postman_collection.json` into Postman.

Run:

- Health
- Register
- Login
- Get Tasks
- Create Task

For authenticated endpoints, copy the JWT token from the Login response into the collection variable `token`.

## STEP 8 — GitHub
From the project root:

```powershell
git init
git add .
git commit -m "Complete Codveda full-stack internship project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Before `git add .`, confirm `.env` is not being included.

## STEP 9 — 60–90 second demo video
Use this exact script:

"Hello, this is my Codveda Full-Stack Development internship project, a Student Task Management System. The project uses HTML, CSS and Vanilla JavaScript for the basic frontend, React for the modern frontend, Node.js and Express for REST APIs, MongoDB with Mongoose for database operations, JWT and bcrypt for authentication, and Socket.io for real-time updates. I implemented CRUD task operations, protected routes, role-based access and responsive UI. The project is available in my GitHub repository."

## STEP 10 — LinkedIn
Use the Codveda instructions from the assignment PDF. Mention/tag `@Codveda` and include the requested hashtags and GitHub/video links.

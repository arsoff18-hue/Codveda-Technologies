import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';
import { connectDB } from './config/db.js';
import authRoutes from './routes/auth.js';
import taskRoutes from './routes/tasks.js';

const app = express();
const server = http.createServer(app);
const isAllowedOrigin = (origin) => {
  const configuredOrigin = process.env.CLIENT_URL;
  if (!origin || !configuredOrigin || configuredOrigin === '*') return true;
  if (origin === configuredOrigin) return true;
  if (process.env.NODE_ENV === 'production') return false;

  try {
    const { hostname } = new URL(origin);
    return hostname === 'localhost' || hostname === '127.0.0.1';
  } catch {
    return false;
  }
};
const allowOrigin = (origin, callback) => {
  callback(null, isAllowedOrigin(origin));
};
const io = new Server(server, { cors: { origin: allowOrigin, methods: ['GET', 'POST', 'PUT', 'DELETE'] } });

app.use(cors({ origin: allowOrigin }));
app.use(express.json());
app.use((req, _res, next) => { req.io = io; next(); });

app.get('/', (_req, res) => res.json({ message: 'Codveda Task Manager API is running', version: '1.0.0' }));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', database: 'MongoDB/Mongoose', realtime: 'Socket.io' }));
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);

io.on('connection', (socket) => {
  socket.on('joinUserRoom', (userId) => {
    if (userId) socket.join(`user:${userId}`);
  });
  socket.on('disconnect', () => {});
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: 'Server error', error: process.env.NODE_ENV === 'production' ? undefined : err.message });
});

const PORT = process.env.PORT || 5000;
connectDB().then(() => {
  server.listen(PORT, () => console.log(`🚀 API running at http://localhost:${PORT}`));
}).catch(err => {
  console.error('❌ MongoDB connection failed:', err.message);
  process.exit(1);
});

import 'dotenv/config';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import User from '../models/User.js';

const run = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const email = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
  const password = process.env.ADMIN_PASSWORD || 'Admin@12345';
  const hashed = await bcrypt.hash(password, 10);
  const existing = await User.findOne({ email });
  if (existing) {
    existing.role = 'admin';
    existing.password = hashed;
    existing.name = 'Codveda Admin';
    await existing.save();
    console.log(`✅ Admin updated: ${email}`);
  } else {
    await User.create({ name: 'Codveda Admin', email, password: hashed, role: 'admin' });
    console.log(`✅ Admin created: ${email}`);
  }
  await mongoose.disconnect();
};
run().catch(err => { console.error(err); process.exit(1); });

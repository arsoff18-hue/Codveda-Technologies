import express from 'express';
import Task from '../models/Task.js';
import User from '../models/User.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = express.Router();
router.use(auth);

router.get('/', async (req, res, next) => {
  try {
    const filter = req.user.role === 'admin' ? {} : { $or: [{ createdBy: req.user.id }, { assignedTo: req.user.id }] };
    const tasks = await Task.find(filter).populate('createdBy', 'name email').populate('assignedTo', 'name email').sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) { next(err); }
});

router.get('/users', requireRole('admin'), async (_req, res, next) => {
  try { res.json(await User.find().select('name email role').sort({ name: 1 })); }
  catch (err) { next(err); }
});

router.post('/', async (req, res, next) => {
  try {
    const { title, description, priority, assignedTo } = req.body;
    if (!title) return res.status(400).json({ message: 'Title is required' });
    if (assignedTo && !(await User.findById(assignedTo))) return res.status(400).json({ message: 'Assigned user not found' });
    const task = await Task.create({ title, description, priority, assignedTo: assignedTo || null, createdBy: req.user.id });
    const populated = await task.populate([{ path: 'createdBy', select: 'name email' }, { path: 'assignedTo', select: 'name email' }]);
    req.io.emit('task:created', { task: populated });
    if (populated.assignedTo?._id) req.io.to(`user:${populated.assignedTo._id}`).emit('notification', { message: `New task assigned: ${populated.title}`, taskId: populated._id });
    res.status(201).json(populated);
  } catch (err) { next(err); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    const canEdit = req.user.role === 'admin' || String(task.createdBy) === req.user.id;
    if (!canEdit) return res.status(403).json({ message: 'You can only edit your own tasks' });
    const { title, description, status, priority, assignedTo } = req.body;
    Object.assign(task, { title, description, status, priority, assignedTo: assignedTo || null });
    await task.save();
    const populated = await task.populate([{ path: 'createdBy', select: 'name email' }, { path: 'assignedTo', select: 'name email' }]);
    req.io.emit('task:updated', { task: populated });
    res.json(populated);
  } catch (err) { next(err); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    const canDelete = req.user.role === 'admin' || String(task.createdBy) === req.user.id;
    if (!canDelete) return res.status(403).json({ message: 'You can only delete your own tasks' });
    await task.deleteOne();
    req.io.emit('task:deleted', { taskId: req.params.id });
    res.json({ message: 'Task deleted successfully' });
  } catch (err) { next(err); }
});

export default router;

import React, { useEffect, useState } from 'react';

const API='http://localhost:5000/api';
const authHeaders=()=>({ 'Content-Type':'application/json', ...(localStorage.getItem('token')?{Authorization:`Bearer ${localStorage.getItem('token')}`}:{}) });

async function request(path, options={}){
  const res=await fetch(API+path,{...options,headers:{...authHeaders(),...(options.headers||{})}});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message||'Request failed');
  return data;
}

export default function App({socket}){
  const [user,setUser]=useState(JSON.parse(localStorage.getItem('user')||'null'));
  const [mode,setMode]=useState('login'); const [form,setForm]=useState({name:'',email:'',password:''});
  const [tasks,setTasks]=useState([]); const [task,setTask]=useState({title:'',description:'',priority:'medium'}); const [message,setMessage]=useState('');

  const load=async()=>{ if(!user)return; try{setTasks(await request('/tasks'));}catch(e){setMessage(e.message)} };
  useEffect(()=>{load()},[user]);
  useEffect(()=>{
    socket.on('notification',(data)=>{setMessage('🔔 '+data.message); load();});
    socket.on('task:created',load); socket.on('task:updated',load); socket.on('task:deleted',load);
    return()=>{socket.off('notification');socket.off('task:created');socket.off('task:updated');socket.off('task:deleted')};
  },[socket,user]);
  useEffect(()=>{if(user)socket.emit('joinUserRoom',user.id)},[socket,user]);

  async function submitAuth(e){
    e.preventDefault(); setMessage('');
    try{const path=mode==='login'?'/auth/login':'/auth/register';const data=await request(path,{method:'POST',body:JSON.stringify(form)});localStorage.setItem('token',data.token);localStorage.setItem('user',JSON.stringify(data.user));setUser(data.user)}catch(e){setMessage(e.message)}
  }
  async function createTask(e){e.preventDefault();try{await request('/tasks',{method:'POST',body:JSON.stringify(task)});setTask({title:'',description:'',priority:'medium'});await load()}catch(e){setMessage(e.message)}}
  async function del(id){try{await request('/tasks/'+id,{method:'DELETE'});await load()}catch(e){setMessage(e.message)}}
  function logout(){localStorage.clear();setUser(null);setTasks([])}

  if(!user) return (
    <div className="auth-shell">
      <div className="auth-panel brand-panel">
        <div className="brand-badge">TM</div>
        <h1>Task Manager</h1>
        <p className="brand-quote">“Turn your plans into progress, one task at a time.”</p>
      </div>

      <div className="auth-panel auth-card">
        <div className="auth-header">
          <span className="eyebrow">{mode === 'login' ? 'Welcome back' : 'Create account'}</span>
          <h2>{mode === 'login' ? 'Login' : 'Register'}</h2>
        </div>

        <form onSubmit={submitAuth}>
          {mode === 'register' && (
            <input placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          )}
          <input type="email" placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          <input type="password" placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required minLength="6" />
          <button>{mode === 'login' ? 'Login' : 'Create account'}</button>
        </form>

        <button className="link" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? 'Need an account? Register' : 'Already registered? Login'}
        </button>

        {message && <p className="status-message">{message}</p>}
      </div>
    </div>
  );

  const completedTasks = tasks.filter(item => item.status === 'completed').length;
  const activeTasks = tasks.filter(item => item.status !== 'completed').length;

  return (
    <main className="dashboard-shell">
      <header className="dashboard-header">
        <div className="dashboard-brand">
          <div className="dashboard-brand-badge">TM</div>
          <div>
            <span className="dashboard-kicker">TASK MANAGER</span>
            <h1>Your workspace</h1>
          </div>
        </div>
        <div className="dashboard-user">
          <div className="user-avatar">{user.name?.charAt(0).toUpperCase()}</div>
          <div className="user-details">
            <strong>{user.role === 'admin' ? 'ADMIN' : user.name}</strong>
            <span>{user.role}</span>
          </div>
          <button className="logout-button" onClick={logout}>Logout</button>
        </div>
      </header>

      <section className="dashboard-welcome">
        <div>
          <span className="dashboard-kicker">YOUR DAILY PROGRESS</span>
          <h2>Make today count.</h2>
          <p>Keep your tasks moving forward, one step at a time.</p>
        </div>
        <div className="dashboard-stats">
          <div className="stat-card">
            <span className="stat-icon total-icon">▤</span>
            <div><strong>{tasks.length}</strong><span>Total tasks</span></div>
          </div>
          <div className="stat-card">
            <span className="stat-icon active-icon">◷</span>
            <div><strong>{activeTasks}</strong><span>In progress</span></div>
          </div>
          <div className="stat-card">
            <span className="stat-icon completed-icon">✓</span>
            <div><strong>{completedTasks}</strong><span>Completed</span></div>
          </div>
        </div>
      </section>

      <div className="dashboard-grid">
        <section className="card create-card">
          <div className="section-heading">
            <span className="section-icon">＋</span>
            <div>
              <h2>Create a task</h2>
              <p>Add something you want to get done.</p>
            </div>
          </div>
          <form onSubmit={createTask}>
            <label htmlFor="task-title">Task title</label>
            <input id="task-title" placeholder="e.g. Finish project proposal" value={task.title} onChange={e => setTask({ ...task, title: e.target.value })} required />
            <label htmlFor="task-description">Description <span>(optional)</span></label>
            <textarea id="task-description" placeholder="Add a few details..." value={task.description} onChange={e => setTask({ ...task, description: e.target.value })} rows="4" />
            <label htmlFor="task-priority">Priority</label>
            <select id="task-priority" value={task.priority} onChange={e => setTask({ ...task, priority: e.target.value })}>
              <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
            </select>
            <button className="create-button">＋ Add task</button>
          </form>
          {message && <p className="dashboard-message">{message}</p>}
        </section>

        <section className="card tasks-card">
          <div className="section-heading tasks-heading">
            <div>
              <h2>Your tasks</h2>
              <p>Everything you’re working on.</p>
            </div>
            <span className="task-count">{tasks.length} {tasks.length === 1 ? 'task' : 'tasks'}</span>
          </div>
          {tasks.length === 0 ? (
            <div className="empty-state">
              <span className="empty-icon">✓</span>
              <h3>Nothing on your list yet</h3>
              <p>Create your first task to get started.</p>
            </div>
          ) : (
            <div className="task-list">
              {tasks.map(item => (
                <article className="task-card" key={item._id}>
                  <div className="task-card-main">
                    <span className={`task-status status-${item.status}`}>{item.status}</span>
                    <h3>{item.title}</h3>
                    {item.description && <p>{item.description}</p>}
                    <span className={`priority-badge priority-${item.priority}`}>{item.priority} priority</span>
                  </div>
                  <button className="delete-button" onClick={() => del(item._id)} aria-label={`Delete ${item.title}`}>Delete</button>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
